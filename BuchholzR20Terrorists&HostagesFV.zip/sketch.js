var fr = 24;
var score = 0;
var hostage =0;
var terror =0;
var pubspeed= false;
var gamespeed =3;
var timer=0;
var pubtimer=0;
//variables for ellipses:
var hosorb1;
var hosorb2;
var tergen=0;
var tergen2=0;
var tergen3=0
var tergen4=0
var tergen5=0
var terrayX=0;
var terrayY=0;
//hitboxes:
var terrorist1 = false;
var terrorist2 = false;
var terrorist3 = false;
var terrorist4 = false;
var terrorist5 = false;
//images:
var terrorIM;
var hostagIM;
var backgroundIM;
var hurtIM
//mostly setup code:
function preload(){
  terrorIM=loadImage('/assets/terrorSprite.png');
  hostagIM=loadImage('/assets/hostageSprite.png');
  backgroundIM=loadImage('/assets/bgasset2.png');
  hurtIM=loadImage('/assets/hurtFV.png');
}
function orbRun(){
  tergen =random(26,474);
  tergen2=random(26,474);
  tergen3=random(26,474);
  tergen4=random(26,474);
  tergen5=random(26,474);
  hosorb1=random(26,474);
  hosorb2=random(26,474);
}
function setup() {
  
  createCanvas(500,570);
  frameRate(fr);
  orbRun();
  colorMode(RGB,255,255,255,100)
}
function hurt(){
  image(hurtIM,0,0)

}
//Most of the actual game code:
function terText(){
  textSize(15);
  timer=timer+1;
  if(timer>=gamespeed){
    timer=0;
    pubtimer=pubtimer+0.125;
  }
  fill(0,0,0);
  var terrayX=[tergen,tergen2,tergen3,tergen4,tergen5]
  var terrayY=[tergen5,tergen4,tergen3,tergen2,tergen]  
  // text("T",terrayX[0],terrayY[0])
  // text("T",terrayX[1],terrayY[1])
  // text("T",terrayX[2],terrayY[2])
  // text("T",terrayX[3],terrayY[3])
  // text("T",terrayX[4],terrayY[4])
  // text("H",hosorb1,hosorb2)
    let finalScore = score+" points!"
    let hostageScore= hostage+" Hostages hit (-10)"
    let terrorScore= terror+" Terrorists hit (+2)"
    text(terrorScore,50,525)
    text(finalScore,200,525);
    //text("All move after 10 sec",50,545)
    text("TIMER: "+pubtimer,200,545);
    text(hostageScore,300,525);
    text("30+ quickmode: "+pubspeed,300,545);
    fill(255,255,255,0);
    if(pubtimer>=10){
      orbRun();
      pubtimer=0;
      score=score-5;
      image(hurtIM,0,0)
    }
    if(score>=30){
      gamespeed=gamespeed-1;
      pubspeed=true;
    }else{
      pubspeed=false;
    }
}
function draw() {
  
  var terrayX=[tergen3,tergen2,tergen,tergen4,tergen5]
  var terrayY=[tergen5,tergen,tergen3,tergen2,tergen4]  
  image(backgroundIM,0,0)
    ellipse(terrayX[0], terrayY[0], 50, 50);
    ellipse(terrayX[1], terrayY[1], 50, 50);
    ellipse(terrayX[2], terrayY[2], 50, 50);
    ellipse(terrayX[3], terrayY[3], 50, 50);
    ellipse(terrayX[4], terrayY[4], 50, 50);
    ellipse(hosorb1, hosorb2, 50,50);
  image(terrorIM,terrayX[0]-25,terrayY[0]-25);
  image(terrorIM,terrayX[1]-25,terrayY[1]-25);
  image(terrorIM,terrayX[2]-25,terrayY[2]-25);
  image(terrorIM,terrayX[3]-25,terrayY[3]-25);
  image(terrorIM,terrayX[4]-25,terrayY[4]-25);
  image(hostagIM,hosorb1-25,hosorb2-25);
    terText();
  
    point(mouseX, mouseY);
    terrorist1 = collidePointEllipse(mouseX, mouseY, terrayX[0], terrayY[0], 50, 50);
    terrorist2 = collidePointEllipse(mouseX, mouseY, terrayX[1], terrayY[1], 50, 50);
    terrorist3 = collidePointEllipse(mouseX, mouseY, terrayX[2], terrayY[2], 50, 50);
    terrorist4 = collidePointEllipse(mouseX, mouseY, terrayX[3], terrayY[3], 50, 50);
    terrorist5 = collidePointEllipse(mouseX, mouseY, terrayX[4], terrayY[4], 50, 50);
    badins = collidePointEllipse(mouseX, mouseY, hosorb1, hosorb2, 50, 50);
  
}
function mousePressed(){
      if(terrorist1==true){
        terror=terror+1;
        score =score+ 2;
        pubtimer=0;
        orbRun();
      }else if(terrorist2==true){
        terror=terror+1;
        score =score+ 2;
        pubtimer=0;
        orbRun();
      }else if(terrorist3==true){
        terror=terror+1;
        score =score+ 2;
        pubtimer=0;
        orbRun();
      }else if (terrorist4==true){
        terror=terror+1;
        score =score+ 2;
        pubtimer=0;
        orbRun();
      }else if(terrorist5==true){
        terror=terror+1;
        score =score+ 2;
        pubtimer=0;
        orbRun();
       }else if(badins==true){
        score =score-10;
        hostage =hostage+1;
        pubtimer=0;
        hurt()
         if(hostage>=3){
           remove();
         }
         orbRun();
       }else{
         hurt()
         score =score-2;
       }
    }